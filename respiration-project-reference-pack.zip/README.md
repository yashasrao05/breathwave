# Respiration audio project reference pack

Build a student-level Streamlit GUI that estimates respiration rate from recorded audio using a transparent DSP pipeline. The immediate goal is a working midterm prototype. Continue to the final project only after the midterm checkpoint is reviewed.

**Prepared:** 23 November 2026. **Working midterm target:** 28 November 2026, based on the latest planning discussion. The originally pasted announcement lists 24 October 2026; confirm the actual final submission date separately.

**Current state:** documentation only. No app, recordings, implementation tests, or experimental results have been created by this pack.

**Private reference page:** [Respiration audio project implementation guide](https://chatgpt.com/space/page_afb4aa01c48481918bc14b93a6553274). The local files below are the working copies to update during implementation; the Page is a planning reference snapshot.

## Start another implementation chat

1. Open this project folder in the new chat, or attach the reference pack if the chat cannot access it.
2. Read [Start here](docs/00_START_HERE.md).
3. Copy **Prompt 0** from [Implementation prompts](docs/02_IMPLEMENTATION_PROMPTS.md).
4. Send prompts **M1 to M5**, one at a time. Review the output of each step.
5. Stop at the [Midterm checkpoint](docs/03_MIDTERM_CHECKPOINT.md).
6. After the midterm, explicitly start **F1 to F5** to complete the final project.

The prompts request actual implementation and verification. They are designed to preserve a simple codebase that both team members can explain.

## Reference documents

| File | Purpose |
| --- | --- |
| [Start here](docs/00_START_HERE.md) | Goal, reading order, milestones, and how to resume |
| [Project blueprint](docs/01_PROJECT_BLUEPRINT.md) | Architecture, DSP settings, formulas, GUI, and failure behavior |
| [Implementation prompts](docs/02_IMPLEMENTATION_PROMPTS.md) | Copyable startup, sequential build, repair, and resume prompts |
| [Midterm checkpoint](docs/03_MIDTERM_CHECKPOINT.md) | Acceptance checklist, pilot procedure, demo, and presentation outline |
| [Final evaluation plan](docs/04_FINAL_EVALUATION_PLAN.md) | Method comparison, SNR protocol, annotation rules, and metrics |
| [Report and viva guide](docs/05_REPORT_AND_VIVA.md) | Report outline, contribution division, and viva questions |
| [Progress and handoff](docs/06_PROGRESS_AND_HANDOFF.md) | Honest status, decisions, checks, and next step |
| [Data templates](docs/templates/README.md) | CSV schemas for recordings, annotations, results, and contributions |

The relative links above are portable when the folder is moved. The project blueprint is the technical source of truth; the progress file records the settings and behavior actually implemented. Update both when an agreed technical decision changes.

## Scope

The required methods are peak detection and autocorrelation. The final result includes quantitative comparison and error versus added-noise SNR. Synthetic audio is an optional engineering aid. This is an educational DSP demonstration, not a medical diagnostic tool.

Do not claim the work is complete from screenshots alone. Keep real measurements, settings, and commands used for verification.
