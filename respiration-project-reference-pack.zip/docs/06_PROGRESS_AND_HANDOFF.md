# Progress and handoff

Use this file as the state record between chats. Update it after each implementation stage. Planned requirements elsewhere are not evidence of completed work.

## Current state

| Field | State |
| --- | --- |
| Last updated | 23 November 2026 |
| Active milestone | Midterm prototype |
| Active stage | Before M1 |
| Documentation pack | Created |
| Application code | Not started |
| Real recordings | Not collected in this workspace |
| Manual labels | Not created |
| GUI verification | Not performed |
| DSP verification | Not performed |
| Experimental results | Not produced |
| Next action | Send Prompt 0 in a new implementation chat, then M1 |
| Final-project phase | Planned; do not start before midterm review |

## Stage tracker

| Stage | Scope | Status | Evidence |
| --- | --- | --- | --- |
| M1 | App shell and audio input | Not started | |
| M2 | Filters, envelope, plots | Not started | |
| M3 | Peak estimate and markers | Not started | |
| M4 | Real-recording pilot | Not started | |
| M5 | Midterm checkpoint | Not started | |
| F1 | ACF and quality | Not started | |
| F2 | Labels, metrics, frozen protocol | Not started | |
| F3 | Method comparison and SNR study | Not started | |
| F4 | Optional synthetic mode | Not started | |
| F5 | Final audit and report | Not started | |

## Actual configuration

The blueprint contains starting defaults. No configuration has yet been implemented or frozen.

When code exists, record: audio band and N; filtering procedure; processing sample rate; RMS window/hop; envelope band and N; analysis margins; peak rules; ACF rules; quality thresholds; tested versions; configuration snapshot path; freeze date.

## Stage update template

Copy this section for each completed or attempted stage:
- Date and stage:
- Implemented files and behavior:
- Commands or checks actually run:
- Measured outputs and evidence paths:
- Manual checks completed:
- Pending checks or missing data:
- Design changes and reason:
- Actual member contributions:
- Next authorized stage:

Use Complete, Partial, Pending, or Failed with a reason. An implemented microphone widget is not the same as verified capture. A result table template is not an experiment.

## Midterm snapshot

To be filled during M5:
- Checkpoint status:
- Launch command and tested environment:
- Demo recording IDs:
- Actual filter and envelope settings:
- Pilot reference and output table:
- Screenshots:
- Known limitations:
- Unverified acceptance items:
- Presentation content:
- User instruction to continue to final project:

Do not remove this snapshot during session 2.

## Final evaluation snapshot

To be filled during F2 to F5:
- Development and evaluation recording IDs:
- Reference label protocol and matching tolerance:
- Frozen configuration path:
- Seeds and SNR levels:
- Per-trial results and summaries:
- MAE and coverage denominators:
- Exclusions and failed estimates:
- Reproduction command:
- Report and contribution records:

## Open matters

- Confirm the actual final submission date. The old pasted deadline and the working midterm date differ.
- Collect real audio and manual labels.
- Verify microphone capture on the intended demo machine.
- Inspect whether inhale/exhale bursts cause duplicate cycle detections.
- Validate starting filter and peak settings on development recordings.
